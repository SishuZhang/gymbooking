from django.forms import ModelForm
from .models import Bookings


class BookingForm(ModelForm):
    class Meta:
        model = Bookings
        fields = '__all__'

