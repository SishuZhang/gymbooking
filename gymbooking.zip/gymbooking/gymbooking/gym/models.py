from django.db import models


class Bookings(models.Model):
    id = models.BigAutoField(primary_key=True)
    user_name = models.CharField(max_length=30)
    user_email = models.EmailField()
    phone_num = models.CharField(max_length=20)
    room = models.CharField(max_length=20)
    booked_time = models.CharField(max_length=20)
    booked_day = models.CharField(max_length=20)

