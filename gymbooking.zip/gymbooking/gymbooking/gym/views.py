from django.shortcuts import render
from django.core.mail import send_mail
from .models import Bookings


def index(request):
    return render(request, 'index.html', {})


def about(request):
    return render(request, 'about.html', {})


def booking(request):
    if request.method == "POST":

        yr_name = request.POST['yr-name']
        yr_email = request.POST['yr-email']
        yr_phone = request.POST['yr-phone']
        yr_room = request.POST['yr-room']
        yr_time = request.POST['yr-time']
        yr_weekday = request.POST['yr-weekday']

        bookings = Bookings(user_name=yr_name, user_email=yr_email, phone_num=yr_phone, room=yr_room,
                            booked_time=yr_time, booked_day=yr_weekday)
        bookings.save()
        print(bookings.id)
        mybookings = Bookings.objects.all()
        return render(request, 'mybooking.html', {'Bookings': mybookings})
    else:
        return render(request, 'booking.html', {})


def mybooking(request):
    return render(request, 'mybooking.html', {})


def contact(request):
    if request.method == "POST":
        message_name = request.POST['message-name']

        return render(request, 'contact.html', {'message_name': message_name})
    else:
        return render(request, 'contact.html', {})


def deleteBooking(request, pk):
    booking = Bookings.objects.get(id=pk)
    booking.delete()
    bookings = Bookings.objects.all()
    return render(request, 'mybooking.html', {'Bookings': bookings})
